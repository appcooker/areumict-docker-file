"use strict";
(self["webpackChunkcodelogging"] = self["webpackChunkcodelogging"] || []).push([["lib_index_js"],{

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI),
/* harmony export */   requestAPIExecutionLogging: () => (/* binding */ requestAPIExecutionLogging)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'codelogging', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}
async function requestAPIExecutionLogging(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, '_', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");



/**
 * Initialization data for the codelogging extension.
 */
const plugin = {
    id: 'codelogging:plugin',
    description: 'A JupyterLab extension.',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, tracker) => {
        console.log('JupyterLab extension codelogging is activated! 3');
        // Function to hook into IPython execution
        function hookExecution(panel) {
            const sessionContext = panel.sessionContext;
            sessionContext.ready.then(() => {
                var _a;
                const kernel = (_a = sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel;
                if (kernel) {
                    kernel.anyMessage.connect((_, msg) => {
                        if (_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.KernelMessage.isExecuteInputMsg(msg.msg)) {
                            const code = msg.msg.content.code;
                            console.log('app', app);
                            console.log('app.shell', app.shell);
                            console.log('tracker', tracker);
                            console.log('panel', panel);
                            console.log('panel', panel.context.path);
                            console.log('IPython code executed:', code, msg);
                            // POST request
                            const dataToSend = {
                                code,
                                username: msg.msg.header.username,
                                session: msg.msg.header.session,
                                date: msg.msg.header.date,
                                baseURI: panel.node.baseURI
                            };
                            (0,_handler__WEBPACK_IMPORTED_MODULE_2__.requestAPIExecutionLogging)('contents', {
                                body: JSON.stringify(dataToSend),
                                method: 'POST'
                            })
                                .then(reply => {
                                console.log(reply);
                            })
                                .catch(reason => {
                                console.error(`Error on POST /_/contents ${dataToSend}.\n${reason}`);
                            });
                        }
                    });
                }
            });
        }
        // Hook into notebook panel creation
        tracker.widgetAdded.connect((_, panel) => {
            panel.sessionContext.ready.then(() => {
                hookExecution(panel);
            });
            panel.sessionContext.kernelChanged.connect((_, kernel) => {
                console.log('kernel changed', kernel);
                // if (kernel) {
                //   kernel.statusChanged.connect((_, status) => {
                //     if (status === 'restarting') {
                //       console.log('Kernel is restarting!');
                //       // Place your custom code here.
                //     }
                //   });
                // }
            });
        });
        // Hook into already open notebooks
        tracker.forEach(panel => {
            if (panel.sessionContext.isReady) {
                hookExecution(panel);
            }
            else {
                panel.sessionContext.ready.then(() => {
                    hookExecution(panel);
                });
            }
        });
        app.serviceManager.sessions.runningChanged.connect((manager, models) => {
            models.forEach(async (model) => {
                const session = await manager.findById(model.id);
                if (session) {
                    // const kernel = session.kernel;
                    // if (kernel) {
                    //   kernel.statusChanged.connect((kernel, status) => {
                    //     console.log('KERNEL STATUS', status);
                    //     //           if (status === 'starting') {
                    //     //             console.log("Kernel is starting")
                    //     //           }
                    //   });
                    //   console.log('kernel CHANGED', kernel);
                    // }
                    console.log('session CHANGED', session);
                }
                console.log('models CHANGED');
            });
            console.log('CHANGED');
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.7c0e5c5d615ae22b2c1e.js.map